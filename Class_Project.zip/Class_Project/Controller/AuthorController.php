<?php
require_once '../Model/Author.php';

class AuthorController
{
    private $author;

   function __construct(){
        $this->author = new Author();
    }

   public function get_all()
    {
        $data=$this->author->get_all();
        return $data;
    }

    public function create_author(){
        $author_name  = $_POST['author_name'];
        $result = $this->author->create_author($author_name);
        header("Location: ../Class_Project/View/create_author.php");
    }

    public function get(){
        $id = $_GET['id'];
        $result=$this->author->get($id);
        return $data;
    }

    public function update_author(){
        $id = $_GET['id'];
        $author_name = $_POST['author_name'];
        $result = $this->author->update_author($id,$author_name);
        header("Location: ../Class_Project/View/create_author.php");
    }

    public function delete_author(){
        $id = $_GET ['id'];
        $result = $this->author->delete_author($id);
        header("Location: ../Class_Project/View/create_author.php");
    }

}

$authorController = new AuthorController();

if(isset($_POST['create-author'])){
  $authorController->create_author();  
}

if(isset($_POST['update-author'])){
    $result = $authorController->get();
    $book = mysqli_fetch_assoc($result);
    return $result;
    header ("Location: ../View/author_update.php");
}

  if(isset($_POST['update'])){
    $authorController->update_author();  
  }

  if(isset($_POST['delete-author'])){
    $authorController->delete_author();  
  }
  
  

?>