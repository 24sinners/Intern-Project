<?php
require_once '../Model/Book.php';

class BookController
{
    private $book;

   function __construct(){
        $this->book = new Book();
    }

   public function get_all()
    {
        $data=$this->book->get_all();
        return $data;
    }

    public function book_create(){
        $CODE_NUMBER = $_POST['code_number'];
        $Name = $_POST['name'];
        $Price = $_POST['price'];
        $PublishingDate = $_POST['publishing_date'];
        $Description = $_POST['description'];
        $Edition = $_POST['edition'];
        $Image = $_POST['image'];
        $Save_pdf = $_POST['save_pdf'];
        $Timestamp = $_POST['timestamp'];
        $result = $this->book->book_create($CODE_NUMBER,$Name,$Price,$PublishingDate,$Description,$Edition,$Image,$Save_pdf,$Timestamp);
        header("Location: ../View/book_view.php");
    }

    public function book_update(){
        $id = $_GET['id'];
        $CODE_NUMBER = $_POST['code_number'];
        $Name = $_POST['name'];
        $Price = $_POST['price'];
        $publishingDate = $_POST['publishing_date'];
        $Description = $_POST['description'];
        $Edition = $_POST['edition'];
        $Image = $_POST['image'];
        $Save_pdf = $_POST['save_pdf'];
        $Timestamp = $_POST['timestamp'];
        $result = $this->book->update_book($author_name);
        header("Location: ../View/book_view.php");
    }
   

    public function book_delete(){
        $id = $_GET['id'];
        $result=$this->book->book_delete($id);
        header("Location: ../View/book_view.php");
    }

    public function get(){
        $id = $_GET['id'];
        $result=$this->book->get($id);
        return $data;
    }
}

$bookController = new BookController();
if(isset($_POST['create-book'])){
  $bookController->create_book();  
}
if(isset($_POST['update-book'])){
    $result = $authorController->get();
    $book = mysqli_fetch_assoc($result);
    return $result;
    header ("Location: ../View/book_update.php");
}

  if(isset($_POST['update'])){
    $authorController->update_book();  
  }

  if(isset($_POST['delete-book'])){
    $authorController->delete_book();  
  }
  
?>