<?php 
require_once 'dashi_book_store_dbconfig.php';

class Book{
    private $db_connection;

    function __construct(){
        $dbconfig = new dashi_book_store_dbconfig();
        $this-> db_connection = $dbconfig->db_connection();

    }

    public function get_all(){
        $query ="SELECT * FROM book";
        $data = mysqli_query($thsi->db_connection, $query);
        return $data;
    }

    public function book_create($CODE_NUMBER,$Name,$Price,$PublishingDate,$Description,$Edition,$Image,$Save_pdf)
    {
        $query = "INSERT INTO `book` (`code_number`,`name`,`price`,`publishing_date`,`description`,`edition`,`image`,`save_pdf`) values ('$CODE_NUMBER','$Name','$Price','$PublishingDate','$Description','$Edition','$Image','$Save_pdf')";
        $data=mysqli_query($db_connection,$query);
        if($data === TRUE)
        {
            echo "New Record created successfully!!";
        }else {
            echo "Error:" . mysqli_error($db_connection);
        }
    }

    public function book_update($id,$author_name){
        $query = "UPDATE `book` SET `code_number`='$CODE_NUMBER',`name`='$Name',`price`='$Price',`publishing_date`='$PublishingDate',`description`='$Description',`edition`='$Edition',`image`='$Image',`save_pdf`='$Save_pdf' WHERE id='$id'";    
        $data = mysqli_query ($this->db_connection, $query);
        return $data;
    }


    public function book_delete($id){
        $query= "DELETE From `book` WHERE id='$id'";    
        $data = mysqli_query ($this->db_connection, $query);
        return $data;
    }
    
    public function get($id){
        $query = "SELECT * FROM book where id = '$id'";
        $data = mysqli_query ($this->db_connection, $query);
        return $data;
    }
    
    


}
?>