<?php
class dashi_book_store_dbconfig 
{
    private $host = "localhost";
    private $user = "HSMLD";
    private $password = "Dashionthegogo";
    private $database = "dashi_book_store";

    public function db_connection()
    {
        $connection = mysqli_connect($this->host, $this->user, $this->password, $this->database);
        return $connection;
    }
}
?>