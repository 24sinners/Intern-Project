<?php 
require_once 'dashi_book_store_dbconfig.php';

class Author{
    private $db_connection;

    function __construct(){
        $dbconfig = new dashi_book_store_dbconfig();
        $this->db_connection = $dbconfig->db_connection();
    }

    function get_all(){
        $query ="SELECT * FROM author";
        $data = mysqli_query($this->db_connection, $query);
        return $data;
    }

    public function create_author($author_name){
        $query ="INSERT INTO `author` (`author_name`) VALUES ('$author_name')";
        $data=mysqli_query($this->db_connection,$query);

        if($data !== false){
            echo "New Record created successfully!!";
        }else {
            echo "Error:" . mysqli_error($this->db_connection);
        }

    }

    public function delete_author($id){
    $query= "DELETE From `author` WHERE id='$id'";    
    $data = mysqli_query ($this->db_connection, $query);
    return $data;
    }

    public function get($id){
        $query = "SELECT * FROM author where id = '$id'";
        $data = mysqli_query ($this->db_connection, $query);
         return $data;
    }

    public function update_author($id,$author_name){
        $query = "UPDATE `author` SET `author_name`='$auhthor_name' WHERE id='$id'";    
        $data = mysqli_query ($this->db_connection, $query);
        return $data;
    }
}
?>