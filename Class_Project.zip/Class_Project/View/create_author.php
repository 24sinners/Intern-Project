<?php
require_once '../Controller/AuthorController.php';
$authorController = new AuthorController();
$result = $authorController->get_all();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel = "stylesheet" href = "css/bootstrap.min.css">
<link rel = "stylesheet" href = "css/all.css">
    <link rel = "stylesheet" href = "js/bootstrap.bundle.min.js">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Author_Insert</title>
</head> 
<body>

    <form action="#" method="post" class = "container col-md-4">
        <label for="title">Please insert data</label>
            <div class="form-group">
                 <label for="exampleInputPassword1">Author Name</label>
                     <input type="text" class="form-control" name="author_name" id="exampleInputPassword1" placeholder="name">
            </div><br>
             
         <button type="submit" class="btn btn-primary" name ="create-author">Submit</button>       
                 
    </form>
    <div class="container col-md-1">

    <a href="author_table.php">
     <button type="submit" class="btn btn-primary" title="show">Show Data</button>
    </a>

    </div>  
    
</body>
</html>
